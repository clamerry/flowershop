<?php
function open_database_connection()
{
    return new PDO("mysql:host=127.0.0.1;dbname=flower", "root", "");
}

function close_database_connection(&$connection)
{
    $connection = null;
}

function get_status_stok()
{ // View

}

function get_single_status_stok($id)
{
    $connection = open_database_connection();
    $query = 'SELECT * FROM storage WHERE id_bunga=:id';
    $statement = $connection->prepare($query);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    $statement->execute();
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    close_database_connection($connection);
    /*var_dump($row);
    die();*/
    return $row['jumlah_stok'];
}

function get_riwayat_transaksi()
{

}

function get_stok_view()
{
    $connection = open_database_connection();
    $result = $connection->query('SELECT * FROM cek_stok');
    $stok_view = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $stok_view[] = $row;
    }
    close_database_connection($connection);
    return $stok_view;
}

function get_single_bunga($id_bunga)
{
    $connection = open_database_connection();
    $query = 'SELECT * FROM cek_stok WHERE id_bunga=:id';
    $statement = $connection->prepare($query);
    $statement->bindValue(':id', $id_bunga, PDO::PARAM_INT);
    $statement->execute();
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    close_database_connection($connection);
    return $row;
}

function insert_bunga($nama_bunga, $harga, $stok)
{
    $connection = open_database_connection();
    $query1 = 'INSERT INTO jenis_bunga (nama_bunga, harga) VALUES (:nama_bunga, :harga)';
    $statement1 = $connection->prepare($query1);

    if (!$statement1->execute(array(
        ':nama_bunga' => $nama_bunga,
        ':harga' => $harga
    ))) die($statement1->errorInfo());

    else {
        $query2 = 'INSERT INTO storage (storage.jumlah_stok) VALUES (:stok)';
        $statement2 = $connection->prepare($query2);
        if (!$statement2->execute(array(
            ':stok' => $stok
        ))) die($statement2->errorInfo());
    }
    return 'success';
}

function update_stok_bunga($id_bunga, $stok)
{
    $connection = open_database_connection();
    /*var_dump($id_bunga);
    var_dump($stok);
    die();*/

    $query = 'UPDATE storage SET jumlah_stok=:stok WHERE id_bunga=:id_bunga';
    $statement = $connection->prepare($query);
    $statement->bindValue(':id_bunga', $id_bunga, PDO::PARAM_INT);
    $statement->bindValue(':stok', $stok, PDO::PARAM_INT);

    if ($statement->execute()) $status = "success";
    else $status = implode(" ", $statement->errorInfo());
    close_database_connection($connection);
    return $status;
}

function remove_bunga($id) {
    $connection = open_database_connection();
    $query = 'DELETE FROM jenis_bunga WHERE jenis_bunga.id_bunga=:id';
    $statement = $connection->prepare($query);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    if ($statement->execute()) $status = "success";
    else $status = implode(" ", $statement->errorInfo());
    close_database_connection($connection);
    return $status;
}

function insert_transaksi($nama_pembeli, $no_telp, $id_bunga, $jumlah)
{
    $connection = open_database_connection();
    $query1 = 'INSERT INTO pembeli (Nama, no_telp) VALUES (:nama_pembeli, :no_telp)';
    $statement1 = $connection->prepare($query1);
    $statement1->bindValue(':nama_pembeli', $nama_pembeli, PDO::PARAM_STR);
    $statement1->bindValue(':no_telp', $no_telp, PDO::PARAM_STR);
    $statement1->execute();
    $id_pembeli = $connection->lastInsertId();

    $stok_bunga = get_single_status_stok($id_bunga);
    $stok_bunga = $stok_bunga - $jumlah;
    $query2 = 'UPDATE storage SET jumlah_stok=:stok_bunga where id_bunga=:id_bunga';
    $statement2 = $connection->prepare($query2);
    $statement2->bindValue(':stok_bunga', $stok_bunga, PDO::PARAM_INT);
    $statement2->bindValue(':id_bunga', $id_bunga, PDO::PARAM_INT);
    $statement2->execute();


    $query3 = 'INSERT INTO transaksi (id_pembeli, id_storage, tanggal) VALUES (:id_pembeli, :id_storage, current_timestamp())';
    $statement3 = $connection->prepare($query3);
    $statement3->bindValue(':id_pembeli', $id_pembeli, PDO::PARAM_INT);
    $statement3->bindValue(':id_storage', $id_bunga, PDO::PARAM_INT);
    if ($statement3->execute()) $status = $connection->lastInsertId();
    else $status = implode(" ", $statement3->errorInfo());
    close_database_connection($connection);
    return $status;
}

function get_single_transaksi($id)
{
    $connection = open_database_connection();
    $query = 'SELECT * FROM cek_transaksi WHERE id_transaksi=:id';
    $statement = $connection->prepare($query);
    $statement->bindValue(':id', $id, PDO::PARAM_INT);
    $statement->execute();
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    close_database_connection($connection);
    return $row;
}

function get_last_id($table, $column)
{
    $connection = open_database_connection();
    $query = 'SELECT :column FROM :table ORDER BY :column DESC LIMIT 1';
    $statement = $connection->prepare($query);
    $statement->bindValue(':table', $table, PDO::PARAM_STR);
    $statement->bindValue(':column', $column, PDO::PARAM_STR);
    $statement->execute();
    close_database_connection($connection);
    return $statement->fetch(PDO::FETCH_ASSOC);
}

function get_login($username, $password)
{
    $connection = open_database_connection();
    $query = 'SELECT * FROM user WHERE username=:username AND password=:password';
    $statement = $connection->prepare($query);
    $statement->bindValue(':username', $username, PDO::PARAM_STR);
    $statement->bindValue(':password', $password, PDO::PARAM_STR);
    $statement->execute();
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    close_database_connection($connection);
    return $row;
}