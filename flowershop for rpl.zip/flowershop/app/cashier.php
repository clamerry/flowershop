<?php

function cashier_controller($action = null)
{
    if (isset($_SESSION['user_id'])) {
        //$user_data = get_user_view($_SESSION['user_id']);
        //$posts_by_user = get_user_posts($_SESSION['user_id']);
        if (!isset($action)) { // Main Home view renders here
            echo get_kumis()->render('user.cashier', array(
                'reply' => isset($_SESSION['reply']) ? $_SESSION['reply'] : null,
                'title' => 'Cashier',
            ));
            unset($_SESSION['reply']); // So that status only shows once
        }
        elseif (isset($action) && $action === 'create_transaction') {
            if (isset($_POST['nama_pelanggan']) && isset($_POST['no_telp']) && isset($_POST['jenis_bunga']) && isset($_POST['jumlah'])) {
                $_SESSION['jumlah_bunga'] = $_POST['jumlah'];
                $_SESSION['reply'] = insert_transaksi($_POST['nama_pelanggan'], $_POST['no_telp'], $_POST['jenis_bunga'], $_POST['jumlah']);
                header('location: /receipt');
            } else header('location: /');
        }
        elseif (isset($action) && $action === 'receipt') {
            $receipt = get_single_transaksi($_SESSION['reply']);
            $data_bunga = get_single_bunga($receipt['id_storage']);
            $jumlah = $_SESSION['jumlah_bunga'];
            unset($_SESSION['jumlah_bunga']);
            unset($_SESSION['reply']);
            if (isset($receipt)) {
                echo get_kumis()->render('user.receipt', array(
                    'reply' => isset($_SESSION['reply']) ? $_SESSION['reply'] : null,
                    'title' => 'Receipt',
                    'Nama' => $receipt['Nama'],
                    'nama_bunga' => $data_bunga['nama_bunga'],
                    'jumlah' => $jumlah,
                    'harga_satuan' => $data_bunga['harga'],
                    'total' => $jumlah * $data_bunga['harga']
                ));
            } else header('location: /');
        }
    }
    else {
        $_SESSION['error'] = 'Session expired';
        header('location: /login');
    }
}