<?php

function storage_controller($action = null) {
    if (isset($_SESSION['user_id'])) {
        $stok_data = get_stok_view();
        if (!isset($action)) { // Main Home view renders here
            echo get_kumis()->render('user.storage', array(
                'reply' => isset($_SESSION['reply']) ? $_SESSION['reply'] : null,
                'flowers' => $stok_data,
                'title' => 'Storage'
            ));
            unset($_SESSION['reply']); // So that status only shows once
        }
        elseif (isset($action) && $action === 'create_bunga') {
            if (isset($_POST['nama_bunga']) && isset($_POST['harga']) && isset($_POST['stok'])) {
                $_SESSION['reply'] = insert_bunga($_POST['nama_bunga'], $_POST['harga'], $_POST['stok']);
                header('location: /storage');
            }
            else echo get_kumis()->render('user.storage', array(
                'reply' => isset($_SESSION['reply']) ? $_SESSION['reply'] : null,
                'flowers' => $stok_data,
                'title' => 'Storage'
            ));
        }
        elseif (isset($action) && $action === 'edit_stok_bunga') {
            $jumlah_stok = get_single_bunga($_GET['id_bunga'])['jumlah_stok'];
            if (isset($_GET['id_bunga']) && isset($_POST['jumlah_stok'])) {
                $_SESSION['reply'] = update_stok_bunga($_GET['id_bunga'], $_POST['jumlah_stok']);
                header('location: /storage');
            }
            else echo get_kumis()->render('user.storage.edit_stok', array(
                'title' => 'Edit Stock',
                'id_bunga' => $_GET['id_bunga'],
                'jumlah_stok' => $jumlah_stok
            ));
        }
        elseif (isset($action) && $action === 'delete_bunga') {
            $_SESSION['reply'] = remove_bunga($_GET['id_bunga']);
            header('location: /storage');
        }
    }
    else {
        $_SESSION['error'] = 'Session expired';
        header('location: /login');
    }
}