<?php
require_once 'db.php';
require_once 'controllers.php';

session_start();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if ('/' === $uri || '' === $uri) {
    cashier_home();
} elseif ('/create_transaction' === $uri || '/create_transaction/' === $uri) {
    cashier_home('create_transaction');
} elseif (('/receipt' === $uri || '/receipt/' === $uri)) {
    cashier_home('receipt');
}

elseif (strpos($uri, 'storage')) {
    if ('/storage' === $uri || '/storage/' === $uri) storage_home(); // Somehow switch-case doesn't work, so here's if-else
    elseif ('/storage/create_bunga' === $uri || '/storage/create_bunga/' === $uri)
        storage_home('create_bunga');
    elseif ('/storage/edit_stok_bunga' === $uri || '/storage/edit_stok_bunga/' === $uri && isset($_GET['id_bunga'])) // PHP is starting to get really weird
        storage_home('edit_stok_bunga');
    elseif ('/storage/delete_bunga' === $uri || '/storage/delete_bunga/' === $uri && isset($_GET['id_bunga']))
        storage_home('delete_bunga');
    else storage_home();
}


elseif ('/login' === $uri ||'/login/' === $uri) {
    login_form(isset($_SESSION['error']) ? $_SESSION['error'] : null);
} elseif (('/login_post' === $uri ||'/login_post/' === $uri) && isset($_POST['username']) && isset($_POST['password'])) {
    authenticate_login($_POST['username'], $_POST['password']);
} elseif ('/logout' === $uri ||'/logout/' === $uri) {
    user_logout();
}

else {
    not_found_404($uri);
}