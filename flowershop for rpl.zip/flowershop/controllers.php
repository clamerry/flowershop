<?php
require_once dirname(__FILE__).'/vendor/autoload.php';
require_once dirname(__FILE__).'/app/auth.php';
require_once dirname(__FILE__).'/app/cashier.php';
require_once dirname(__FILE__).'/app/storage.php';


/*initialize template object start*/
Mustache_Autoloader::register();
$mustache = new Mustache_Engine(array(
    'loader' =>new Mustache_Loader_FilesystemLoader(dirname(__FILE__).'/views',
        array('extension' => '.mustache')),
    'logger' => new Mustache_Logger_StreamLogger('php://stdout')
));

function get_kumis() { // PHP variable scoping is bullshit
    global $mustache;
    return $mustache;
}
/*initialize template object stop*/

/*public functions start*/
function cashier_home($action = null) {
    cashier_controller($action);
}
/*public functions stop*/

/*public functions start*/
function storage_home($action = null) {
    storage_controller($action);
}
/*public functions stop*/

/*auth functions start*/
function login_form($error) {
    render_login($error);
}
function authenticate_login($uname, $passwd) {
    do_auth($uname, $passwd);
}
function user_logout() {
    do_logout();
}
/*auth functions stop*/

function not_found_404($uri) {
    echo get_kumis()->render('public.404', array(
        'title' => '404 Not Found',
        'uri' => $uri
    ));
}