-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2019 at 04:51 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flower`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `cek_stok`
-- (See below for the actual view)
--
CREATE TABLE `cek_stok` (
`id_rak` int(3)
,`id_bunga` int(3)
,`nama_bunga` varchar(10)
,`harga` varchar(5)
,`jumlah_stok` int(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `cek_transaksi`
-- (See below for the actual view)
--
CREATE TABLE `cek_transaksi` (
`id_transaksi` int(3)
,`Nama` varchar(15)
,`no_telp` varchar(12)
,`tanggal` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_bunga`
--

CREATE TABLE `jenis_bunga` (
  `id_bunga` int(3) NOT NULL,
  `nama_bunga` varchar(10) NOT NULL,
  `harga` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_bunga`
--

INSERT INTO `jenis_bunga` (`id_bunga`, `nama_bunga`, `harga`) VALUES
(1, 'Mawar', '50000'),
(2, 'Anggrek', '30000'),
(3, 'Lili', '40000'),
(4, 'Tulip', '50000'),
(5, 'Hortensia', '70000');

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `id_pembeli` int(3) NOT NULL,
  `Nama` varchar(15) NOT NULL,
  `no_telp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `Nama`, `no_telp`) VALUES
(1, 'Erika S', '081233377448'),
(2, 'Tasya C', '089632274756'),
(3, 'Sayyid', '081526375843'),
(4, 'Lola', '082123456789');

-- --------------------------------------------------------

--
-- Table structure for table `storage`
--

CREATE TABLE `storage` (
  `id_rak` int(3) NOT NULL,
  `id_bunga` int(3) NOT NULL,
  `jumlah_stok` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `storage`
--

INSERT INTO `storage` (`id_rak`, `id_bunga`, `jumlah_stok`) VALUES
(1, 1, 10),
(2, 2, 25),
(3, 3, 15),
(4, 4, 25),
(5, 5, 20);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(3) NOT NULL,
  `id_pembeli` int(3) NOT NULL,
  `id_storage` int(3) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_pembeli`, `id_storage`, `tanggal`) VALUES
(1, 1, 4, '2019-11-12 17:00:00'),
(2, 4, 5, '2019-11-27 17:00:00'),
(3, 2, 1, '2019-11-24 17:00:00'),
(4, 3, 2, '2019-12-30 17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(3) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`) VALUES
(1, 'clamerry', 'azalea');

-- --------------------------------------------------------

--
-- Structure for view `cek_stok`
--
DROP TABLE IF EXISTS `cek_stok`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cek_stok`  AS  select `storage`.`id_rak` AS `id_rak`,`jenis_bunga`.`id_bunga` AS `id_bunga`,`jenis_bunga`.`nama_bunga` AS `nama_bunga`,`jenis_bunga`.`harga` AS `harga`,`storage`.`jumlah_stok` AS `jumlah_stok` from (`storage` join `jenis_bunga` on((`storage`.`id_bunga` = `jenis_bunga`.`id_bunga`))) ;

-- --------------------------------------------------------

--
-- Structure for view `cek_transaksi`
--
DROP TABLE IF EXISTS `cek_transaksi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cek_transaksi`  AS  select `transaksi`.`id_transaksi` AS `id_transaksi`,`pembeli`.`Nama` AS `Nama`,`pembeli`.`no_telp` AS `no_telp`,`transaksi`.`tanggal` AS `tanggal` from (`transaksi` join `pembeli` on((`transaksi`.`id_pembeli` = `pembeli`.`id_pembeli`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jenis_bunga`
--
ALTER TABLE `jenis_bunga`
  ADD PRIMARY KEY (`id_bunga`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `storage`
--
ALTER TABLE `storage`
  ADD PRIMARY KEY (`id_rak`),
  ADD KEY `FK_bunga` (`id_bunga`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `FK_pembeli` (`id_pembeli`),
  ADD KEY `FK_storage` (`id_storage`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jenis_bunga`
--
ALTER TABLE `jenis_bunga`
  MODIFY `id_bunga` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `id_pembeli` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `storage`
--
ALTER TABLE `storage`
  MODIFY `id_rak` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `storage`
--
ALTER TABLE `storage`
  ADD CONSTRAINT `FK_bunga` FOREIGN KEY (`id_bunga`) REFERENCES `jenis_bunga` (`id_bunga`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `FK_pembeli` FOREIGN KEY (`id_pembeli`) REFERENCES `pembeli` (`id_pembeli`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_storage` FOREIGN KEY (`id_storage`) REFERENCES `storage` (`id_rak`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
