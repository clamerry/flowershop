<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Admin :: Flower Shop ::</title>
<link rel="stylesheet" type="text/css" href="../css/style.css" />
<link rel="shortcut icon" href="../images/fav.ico" />
<link rel="stylesheet" href="../css/lightbox.css" type="text/css" media="screen" />
<link rel="stylesheet" href="../css/bg.css"  type="text/css" />
	
	<script src="../js/prototype.js" type="text/javascript"></script>
	<script src="../js/scriptaculous.js?load=effects" type="text/javascript"></script>
	<script src="../js/lightbox.js" type="text/javascript"></script>
      <script type="text/javascript" src="../js/java.js"></script>

</head>
<body>
<div id="admin_wrap">
       <div class="admin_header">
        <div class="logo"><a href="index.php"><img src="../images/logo.png" alt="" title="" border="0" /></a></div>            
        <div id="menu">
            <ul> 
            <li><a href="../index.php">Public Area</a></li>                                                                      
            <li><a href="about_us.php">About us</a></li>
            <li><a href="products_list.php">Products</a></li>
            <li><a href="users_list.php">Users</a></li>
            <li><a href="categories_list.php">Categories</a></li>
            <li><a href="catalogs_list.php">Catalogs</a></li>
	        <li><a href="logs.php">Logs</a></li>
            </ul>
        </div>  
         
       </div> 
       <div class="admin_center_content"> 
       