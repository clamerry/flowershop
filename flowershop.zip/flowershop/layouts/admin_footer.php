       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="admin_footer">
       	<div class="left_footer"><img src="../images/footer_logo.gif" alt="" title="" /><br /> <a href="http://www.mfinfo.net76.net/" title="Copyright Year"><img src="../images/des.png" alt="mfahim" width="60" height="15" border="0" title="Desinger Site" /><?php echo strftime(" &copy; %Y",time()); ?></a></div>
        <div class="right_footer">
            <a href="../index.php">Public Area</a>
            <a href="products_list.php">Products</a>
            <a href="users_list.php">Users</a>
            <a href="categories_list.php">Categories</a>
            <a href="catalogs_list.php">Catalogs</a>
	        <a href="logs.php">Logs</a>
       
        </div>
        
       
       </div>
    

</div>

</body>
</html>